public class Movie {
    private int id; // Assuming you have an ID for each movie
    private String movieName;
    private String genre;
    private int ageRestriction;
    private double price;

    public Movie(int id, String movieName, String genre, int ageRestriction, double price) {
        this.id = id;
        this.movieName = movieName;
        this.genre = genre;
        this.ageRestriction = ageRestriction;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getMovieName() {
        return movieName;
    }

    public String getGenre() {
        return genre;
    }

    public int getAgeRestriction() {
        return ageRestriction;
    }

    public double getPrice() {
        return price;
    }

}
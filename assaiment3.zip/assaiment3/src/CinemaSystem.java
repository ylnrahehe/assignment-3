import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class CinemaSystem {
    private ArrayList<User> users;
    private ArrayList<Movie> movies;
    private ArrayList<Ticket> tickets;
    private int ticketIdCounter;

    public CinemaSystem() {
        this.users = new ArrayList<>();
        this.movies = new ArrayList<>();
        this.tickets = new ArrayList<>();
        this.ticketIdCounter = 1;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Hello, You have the following available functions:");
            System.out.println("1) To add a new movie;");
            System.out.println("2) To show all available movies;");
            System.out.println("3) To add a new user;");
            System.out.println("4) To buy a ticket;");
            System.out.println("5) To cancel a purchase of the ticket.");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addMovie();
                    break;
                case 2:
                    showAllMovies();
                    break;
                case 3:
                    addUser();
                    break;
                case 4:
                    buyTicket();
                    break;
                case 5:
                    cancelTicket();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addMovie() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter movie name:");
        String movieName = scanner.nextLine();

        System.out.println("Enter movie genre:");
        String genre = scanner.nextLine();

        System.out.println("Enter age restriction:");
        int ageRestriction = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter price:");
        double price = scanner.nextDouble();
        scanner.nextLine();

// Insert movie into the database 
        try (Connection connection = DatabaseConnector.connect()) {
            String insertMovieSQL = "INSERT INTO movies (movie_name, genre, age_restriction, price) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertMovieSQL)) {
                preparedStatement.setString(1, movieName);
                preparedStatement.setString(2, genre);
                preparedStatement.setInt(3, ageRestriction);
                preparedStatement.setDouble(4, price);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("Movie added successfully!");
    }

    private void showAllMovies() {
        System.out.println("List of available movies:");
        for (Movie movie : movies) {
            System.out.println("Movie ID: " + movie.getId() + ", Name: " + movie.getMovieName() +
                    ", Genre: " + movie.getGenre() + ", Age Restriction: " + movie.getAgeRestriction() +
                    ", Price: " + movie.getPrice());
        }
    }

    private void addUser() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter user name:");
        String name = scanner.nextLine();

        System.out.println("Enter user age:");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter user balance:");
        double balance = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Is the user a student? (yes/no): ");
        String isStudentInput = scanner.nextLine();
        boolean isStudent = isStudentInput.equalsIgnoreCase("yes");

        System.out.print("Enter subscription type (premium/ordinary): ");
        String subscriptionType = scanner.nextLine();

        OrdinarySubscription subscription;
        if (subscriptionType.equalsIgnoreCase("premium")) {
            subscription = new OrdinarySubscription();
        } else {
            subscription = new OrdinarySubscription();
        }


// Add user to the database 
        try (Connection connection = DatabaseConnector.connect()) {
            String insertUserSQL = "INSERT INTO users (name, age, balance, isStudent, isStudentInput, subscriptionType) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertUserSQL)) {
                preparedStatement.setString(1, name);
                preparedStatement.setInt(2, age);
                preparedStatement.setDouble(3, balance);
                preparedStatement.setBoolean(4, isStudent);
                preparedStatement.setString(5, isStudentInput);
                preparedStatement.setString(6, subscriptionType);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("User added successfully!");
    }


    private void buyTicket() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter user ID:");
        int userId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter movie ID:");
        int movieId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter date:");
        String date = scanner.nextLine();

        System.out.println("Enter time:");
        String time = scanner.nextLine();

// Get the movie price and user balance 
        double moviePrice = 0.0;
        double userBalance = 0.0;

        for (Movie movie : movies) {
            if (movie.getId() == movieId) {
                moviePrice= movie.getPrice();
                break;
            }
        }

        for (User user : users) {
            if (user.getId() == userId) {
                userBalance = user.getBalance();
                break;
            }
        }

// Check if the user can afford the ticket
        if (userBalance >= moviePrice) {
// Deduct the ticket price from the user's balance
            try (Connection connection = DatabaseConnector.connect()) {
                String updateBalanceSQL = "UPDATE users SET balance = ? WHERE id = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(updateBalanceSQL)) {
                    preparedStatement.setDouble(1, userBalance - moviePrice);
                    preparedStatement.setInt(2, userId);
                    preparedStatement.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

// Add the ticket to the database
            try (Connection connection = DatabaseConnector.connect()) {
                String insertTicketSQL = "INSERT INTO tickets (user_id, movie_id, date, time) VALUES (?, ?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(insertTicketSQL)) {
                    preparedStatement.setInt(1, userId);
                    preparedStatement.setInt(2, movieId);
                    preparedStatement.setString(3, date);
                    preparedStatement.setString(4, time);
                    preparedStatement.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            System.out.println("Ticket purchased successfully!");
        } else {
            System.out.println("Insufficient balance. Cannot buy the ticket.");
        }
    }

    private void cancelTicket() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter ticket ID:");
        int ticketId = scanner.nextInt();
        scanner.nextLine();

// Retrieve ticket information from the database
        int userId = 0;
        int movieId = 0;
        double moviePrice = 0.0;

        try (Connection connection = DatabaseConnector.connect()) {
            String selectTicketSQL = "SELECT user_id, movie_id FROM tickets WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectTicketSQL)) {
                preparedStatement.setInt(1, ticketId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        userId = resultSet.getInt("user_id");
                        movieId = resultSet.getInt("movie_id");
                    }
                }
            }

            String selectMoviePriceSQL = "SELECT price FROM movies WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectMoviePriceSQL)) {
                preparedStatement.setInt(1, movieId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        moviePrice = resultSet.getDouble("price");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

// Update user balance in the database
        double userBalance = 0.0;
        try (Connection connection = DatabaseConnector.connect()) {
            String selectBalanceSQL = "SELECT balance FROM users WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectBalanceSQL)) {
                preparedStatement.setInt(1, userId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        userBalance = resultSet.getDouble("balance");
                    }
                }
            }

            String updateBalanceSQL = "UPDATE users SET balance = ? WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateBalanceSQL)) {
                preparedStatement.setDouble(1, userBalance + moviePrice);
                preparedStatement.setInt(2, userId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

// Remove the ticket from the database
        try (Connection connection = DatabaseConnector.connect()) {
            String deleteTicketSQL = "DELETE FROM tickets WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(deleteTicketSQL)) {
                preparedStatement.setInt(1, ticketId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("Ticket canceled successfully!");
    }

    public static void main(String[] args) {
        CinemaSystem cinemaSystem = new CinemaSystem();
        cinemaSystem.run();
    }

    private class PremiumSubscription {
    }
}
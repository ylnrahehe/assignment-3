import java.sql.*;

public class Ticket {
    private int id; // Assuming you have an ID for each ticket
    private int userId; // User ID who purchased the ticket
    private int movieId; // Movie ID for the purchased movie
    private String date;
    private String time;
    private double price;

    public Ticket(int id, int userId, int movieId, String date, String time, double price) {
        this.id = id;
        this.userId = userId;
        this.movieId = movieId;
        this.date = date;
        this.time = time;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public int getMovieId() {
        return movieId;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public double getPrice() {
        return price;
    }


}
public class OrdinarySubscription {
}

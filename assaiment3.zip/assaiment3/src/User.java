import java.sql.*;
import java.util.ArrayList;

public class User {
    private int id; // Assuming you have an ID for each user
    private String name;
    private int age;
    private double balance;
    private boolean isStudent;
    private Subscription subscription;
    private ArrayList<Ticket> orderHistory;

    public User(int id, String name, int age, double balance, boolean isStudent, Subscription subscription) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.balance = balance;
        this.isStudent = isStudent;
        this.subscription = subscription;
        this.orderHistory = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getBalance() {
        return balance;
    }

    public boolean isStudent() {
        return isStudent;
    }

    public Subscription getSubscription() {
        return subscription;
    }

    public ArrayList<Ticket> getOrderHistory() {
        return orderHistory;
    }

// Additional methods...

    public boolean isPremium() {
// Implement logic to check if the user is premium
        return false;
    }

    public void buyTicket(Ticket ticket) {
// Implement logic to handle the purchase of tickets
    }
}
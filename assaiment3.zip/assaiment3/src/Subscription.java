public class Subscription {
}
